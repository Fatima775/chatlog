const app = angular.module('chatlog' , []);

app.value('env' , {
    'SERVICE_URL': 'http://localhost:3000'
});