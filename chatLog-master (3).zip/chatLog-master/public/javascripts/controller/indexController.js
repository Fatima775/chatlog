app.controller('indexController' , ['$scope' , ($scope) => {
    console.log("Selam");
}]);