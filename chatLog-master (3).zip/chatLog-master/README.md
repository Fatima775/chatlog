# chatLog
ChatLog is a chat application.


# ChatLog Login Screen
![chat1](https://user-images.githubusercontent.com/36936802/89285859-cee88600-d659-11ea-8b50-8275f618fa72.PNG)

# ChatLog Homepage Screen
![chat2](https://user-images.githubusercontent.com/36936802/89286235-7fef2080-d65a-11ea-96c4-d784d454c039.PNG)


# ChatLog Chat-room Screen
![chat3](https://user-images.githubusercontent.com/36936802/89286256-89788880-d65a-11ea-9af8-69c5bc69b25f.png)
